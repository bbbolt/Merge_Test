import os
import re
import time
import json
import binascii
import gzip
import asyncio
from collections import defaultdict

import openpyxl

from const.env import MAX_TABLE_AREA, MATCH_TABLE_HOST, MATCH_TABLE_JmAppid, MATCH_TABLE_ClientType, \
    MATCH_TABLE_JmClientEntrance, MATCH_TABLE_TOKEN, SCORE_THRESHOLD, USE_FEWSHOT

from const.const import DEFAULT_JS_TABLE_STRUCTURE, FULL_PROMPT, NEW_PROMPT, PROMPT_DICT, NO_SELECTION_FULL_PROMPT
from table_sl import fmt_header_value, calc_similarity_q_case
from api.third_party import match_table
from util.disaggregation.functions import FUNCTIONS as FUNCTIONS_DISAGGREGATION
from util.pvt.functions import FUNCTIONS as FUNCTIONS_PVT
from util.pvt.functions import CONTEXT_CODE as CONTEXT_CODE_PVT
from util.sort.functions import FUNCTIONS as FUNCTIONS_SORT
from util.hyperlink.functions import FUNCTIONS as FUNCTIONS_HYPERLINK
from util.range_ops.functions import FUNCTIONS as FUNCTIONS_RANGE_OPS
from util.range_ops.functions import CONTEXT_CODE as CONTEXT_CODE_RANGE_OPS
from util.merge.functions import FUNCTIONS as FUNCTIONS_MERGE

def get_date_str():
    """获取日期字符串

    以当前时间、本地时区生成形如"2020-08-16"的日期字符串

    Returns:
        str: 日期字符串
    """
    return time.strftime('%Y-%m-%d', time.localtime(time.time()))


def get_time_str():
    """获取时间字符串

    以当前时间、本地时区生成形如"20200816190324"的时间字符串

    Returns:
        str: 时间字符串
    """
    return time.strftime('%Y%m%d%H%M%S', time.localtime(time.time()))

ALPHABET = ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
            'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z')


def digit2alphabet(digit):
    """10进制 -> 26进制"""
    mod, remainder = divmod(digit, 26)
    alphabet = ALPHABET[remainder]
    while mod:
        mod, remainder = divmod(mod, 26)
        alphabet = ALPHABET[remainder - 1] + alphabet
    return alphabet

def alphabet2digit(alphabet):
    """26进制 -> 十进制"""
    result = 0
    for char in alphabet:
        result = result * 26 + (ord(char.upper()) - ord('A') + 1)
    return result

def norm_question(question, tables):
    question = modify_question(question, tables)
    new_question = question.replace(",", "，")
    return new_question

def modify_question(question, tables):
    """
    headers若有 平均成本这样的字样，在query中找到相同字样，并在后面加上 列 字
    """
    headers = []
    for item in tables:
        headers.extend(item.get("headers", []))
    if not headers:
        return question
    for item in set(headers):
        # 平均成本
        if '平均' not in item:
            continue
        offset = 0
        for matched_item in re.finditer(item, question):
            end = matched_item.end() + offset
            if end < len(question) and question[end] != '列':
                question = question[:end] + '列' + question[end:]
                offset += 1
    return question

def add_functions(code):
    extra_function_tool = ""
    if "DISAGGREGATION_" in code:
        try:
            pattern = r'以下为工具函数，使用的工具函数列表为\[(.*?)\]'
            functions_used = re.findall(pattern, code)[0]
            pattern = r'"(.*?)"'
            functions_used = re.findall(pattern, functions_used)
            functions = {}
            for function in functions_used:
                if function in FUNCTIONS_DISAGGREGATION:
                    functions[function] = FUNCTIONS_DISAGGREGATION[function]
        except:
            # print(code)
            functions = FUNCTIONS_DISAGGREGATION
        context = ''
    elif "PVT_" in code:
        try:
            pattern = r'以下为工具函数，使用的工具函数列表为\[(.*?)\]'
            functions_used = re.findall(pattern, code)[0]
            pattern = r'"(.*?)"'
            functions_used = re.findall(pattern, functions_used)
            functions = {}
            for function in functions_used:
                if function in FUNCTIONS_PVT:
                    functions[function] = FUNCTIONS_PVT[function]
        except:
            # print(code)
            functions = None
        context = CONTEXT_CODE_PVT
    elif "SORT_" in code:
        try:
            pattern = r'以下为工具函数，使用的工具函数列表为\[(.*?)\]'
            functions_used = re.findall(pattern, code)[0]
            pattern = r'"(.*?)"'
            functions_used = re.findall(pattern, functions_used)
            functions = {}
            for function in functions_used:
                if function in FUNCTIONS_SORT:
                    functions[function] = FUNCTIONS_SORT[function]
        except:
            # print(code)
            functions = FUNCTIONS_SORT
        context = ''
    elif "HYBERLINK_" in code:
        try:
            pattern = r'以下为工具函数，使用的工具函数列表为\[(.*?)\]'
            functions_used = re.findall(pattern, code)[0]
            pattern = r'"(.*?)"'
            functions_used = re.findall(pattern, functions_used)
            functions = {}
            for function in functions_used:
                if function in FUNCTIONS_HYPERLINK:
                    functions[function] = FUNCTIONS_HYPERLINK[function]
        except:
            # print(code)
            functions = FUNCTIONS_HYPERLINK
        context = ''
    elif "CLOP_" in code or "FindReplaceColor" in code:
        context = CONTEXT_CODE_RANGE_OPS
        try:
            pattern = r'以下为工具函数，使用的工具函数列表为\[(.*?)\]'
            functions_used = re.findall(pattern, code)[0]
            pattern = r'"(.*?)"'
            functions_used = re.findall(pattern, functions_used)
            functions = {}
            for function in functions_used:
                if function in FUNCTIONS_RANGE_OPS:
                    functions[function] = FUNCTIONS_RANGE_OPS[function]
                # if "GetUnionTableRange" not in functions:
                #     functions["GetUnionTableRange"] = FUNCTIONS_RANGE_OPS["GetUnionTableRange"]
        except:
            # print(code)
            functions = None
    elif "Merge" in code:
        context = ''
        try:
            pattern = r'以下为工具函数，使用的工具函数列表为\[(.*?)\]'
            functions_used = re.findall(pattern, code)[0]
            pattern = r'"(.*?)"'
            functions_used = re.findall(pattern, functions_used)
            functions = {}
            for function in functions_used:
                if function in FUNCTIONS_MERGE:
                    functions[function] = FUNCTIONS_MERGE[function]
        except:
            # print(code)
            functions = None
    # elif "IsCellAddress" in code:
    #     functions = FUNCTIONS_DATASERIES
    else:
        functions, context = None, ''
    if functions:
        for key, value in functions.items():
            code += '\n' + value
            extra_function_tool += '\n' + value
        code += context
        extra_function_tool += context
    return code, extra_function_tool

def extra_pivot_table(result):
    result = result.replace("PivotCreate(targetRange, task_0)", "pvt = targetRange.RequirePivotTable()\n    if (!pvt)\n        PivotCreate(targetRange, task_0)")

    field = re.search(r'pvt\.PivotFields\((.*?)\)\.Orientation = xlPageField', result)
    if field:
        field_name = field.group(1)
        result = result.replace(".Orientation = xlPageField", f".Orientation = xlPageField\n    pvt.PivotFields({field_name}).Position = 1")

    data_field = re.search(r'pvt\.PivotFields\((.*?)\)\.Orientation = xlDataField', result)
    if data_field:
        field_name = data_field.group(1)
        result = re.sub(r'pvt\.PivotFields\((.*?)\)\.Orientation = xlDataField', f"pvt.AddDataField(pvt.PivotFields({field_name}))", result)

    return result

def extra_autofilter(result):
    result = result.replace("let oldRange = targetWorksheet.UsedRange", "let oldRange = targetWorksheet.AutoFilter.Range")
    result = result.replace("targetWorksheet.UsedRange.AutoFilter()", "targetWorksheet.AutoFilter.Range.AutoFilter()")
    return result

def extra_range_format(result):
    try:
        tmp = json.loads(result)
        if len(tmp) > 0:
            return tmp[0]
        else:
            return result
    except:
        return result

def extra_range_format_row1(user_query, result):
    """ 针对设置第一行 """
    if ('设置第一行' in user_query or '设置第1行' or '设置整个工作表的第一行' or '设置整个工作表的第1行') and '取消' not in user_query and '整行' not in user_query:
        data_field = re.search(r'targetRange = Range\(\"\$(.*?)\$(.*?):\$(.*?)\$(.*?)\"\)', result)
        if data_field:
            try:
                field_name1 = data_field.group(1)
                row_name1 = data_field.group(2)
                field_name2 = data_field.group(3)
                row_name2 = data_field.group(4)
                result = re.sub(r'targetRange = Range\(\"\$(.*?)\$(.*?):\$(.*?)\$(.*?)\"\)',
                                f"targetRange = Range(\"${field_name1}$1:${field_name2}$1\")", result)
            except:
                return result
    return result

def extra_range_ops(result):
    result = result.replace("parseFloat(pt).toFixed(2)", "(Math.floor(pt * 20) / 20).toFixed(2)")
    return result


def fix_autofilter_range(result, prompt):
    # 修复筛选中，range写成数据区域，漏掉表头的情况
    if "AutoFilter" not in result:
        return result
    # setp1: 提取模型返回代码里面的range 目前只处理一个range的代码
    pattern = r'Range\("(\$[A-Z]+\$\d+:\$[A-Z]+\$\d+)"\)'
    ranges = re.findall(pattern, result)
    if not ranges or len(ranges) > 1:
        return result

    def check_diff(str1, str2):
        # 定义正则，对于两个range，英文1数字1:英文2数字2，如果只有数字1不相同，则返回True
        pattern = r'^([A-Z]+)(\d+):([A-Z]+)(\d+)$'
        match1 = re.match(pattern, str1)
        match2 = re.match(pattern, str2)
        if not match1 or not match2:
            return False
        if match1.groups()[0] == match2.groups()[0] and match1.groups()[2] == match2.groups()[2] and match1.groups()[3] == match2.groups()[3]:
            return match1.groups()[1] != match2.groups()[1]
        return False
    # step2: 使用正则表达式提取表单区域信息 遍历每个表单，定位有无错误range并进行修复
    pattern = r'表单区域\d+：\n表头起始行号为(\d+)，终止行号为(\d+)，内容起始行号为(\d+)，终止行号为(\d+)，同时每一列的列索引、列名及示例内容为：\{(.+?)\}\n'
    matches = re.findall(pattern, prompt.replace("}。", "}"), re.DOTALL)
    for i, match in enumerate(matches, start=1):
        column_info_list = match[4].split('},{')
        start_column = column_info_list[0].strip('{}').split(',')[0].strip('"')
        end_column = column_info_list[-1].strip('{}').split(',')[0].strip('"')
        if check_diff(ranges[0].replace("$", ""), f"{start_column}{match[0]}:{end_column}{match[3]}"):
            # 如果找到了，则把range替换为表单的全表范围
            return result.replace(ranges[0], f"{start_column}{match[0]}:{end_column}{match[3]}")
    return result

def post_process(user_query, result, prompt):
    unknown_character = '�'
    unknown_character2 = ' [/INST]'
    result = result.replace(unknown_character, '')
    result = result.replace(unknown_character2, "")

    def replace_quotes_around_chinese(text):
        # 使用正则表达式匹配带有双引号的中文字符，然后替换双引号
        pattern = r'=(")([\u4e00-\u9fa5]+)(")'
        return re.sub(pattern, r'=\\"\2\\"', text)

    def format_answer(text):
        text = text.replace("function Marco()", "function Macro()")
        if "function Macro()" not in text:
            return 'function Macro(){\n' + text + '\n}'
            # return 'function Macro(){\n' + text
        else:
            return text

    result = replace_quotes_around_chinese(result)
    # 临时修复macro大小写
    result = result.replace("macro", "Macro")
    result = format_answer(result)
    # result = extra_pivot_table(result)
    # result = extra_autofilter(result)
    # result = extra_range_ops(result)
    result = fix_autofilter_range(result, prompt)
    # result = extra_range_format(result)
    # result = extra_range_format_row1(user_query, result)
    return result

def gen_js_table_structure(input_dict, case_dict):
    """
    构造表格结构描述，
    """
    output = []
    # 选中区域处理
    # 如果没选中区域，默认A1
    selected_start_col = 'A'
    selected_start_row = 1
    selected_end_col = 'A'
    selected_end_row = 1
    prompt = FULL_PROMPT
    try:
        if "selection_range_list" in input_dict and len(input_dict["selection_range_list"]) > 0:
            # 仅先处理第一个选中区域
            for item in input_dict["selection_range_list"][:1]:
                selected_start_col = digit2alphabet(int(item[1]))
                selected_start_row = int(item[0]) + 1

                selected_end_col = digit2alphabet(int(item[3]))
                selected_end_row = int(item[2]) + 1
    except:
        prompt = NO_SELECTION_FULL_PROMPT
    all_sheet_name = input_dict.get("all_sheet_name", [])
    sheet_name = ""

    # 空表处理,返回个默认字符串
    if "tables_json_data" not in input_dict or not input_dict.get('tables_json_data'):
        output.append(DEFAULT_JS_TABLE_STRUCTURE.format(demand=input_dict.get('question', ""),
                                              ALL_SHEET_NAME=json.dumps(all_sheet_name, ensure_ascii=False),
                                              CUR_SHEET_NAME=sheet_name,
                                              selected_start_col=selected_start_col,
                                              selected_start_row=selected_start_row,
                                              selected_end_col=selected_end_col,
                                              selected_end_row=selected_end_row,
                                              active_cell=input_dict.get('active_cell', "")))
        final_output_str = "\n".join(output)
        return final_output_str

    if len(input_dict["tables_json_data"]) > MAX_TABLE_AREA:
        final_output_str = connect_error_tables(input_dict)
        return final_output_str

    table_area_str = """表单区域{idx}：
表头起始行号为{header_start_point}，终止行号为{header_end_point}，内容起始行号为{start_point}，终止行号为{end_point}，同时每一列的列索引、列名及示例内容为：{table_structure}。"""

    table_header_dict = {}
    num = 0
    sheet_name = ""
    max_score_lst = []
    max_score_idx = 0
    for i, data_dict in enumerate(input_dict["tables_json_data"]):
        sheet_name = data_dict['sheet_name']
        # if data_dict.get("title"):
        #     title = data_dict["title"]
        #     new_table_info_header_data += """,表格标题为：{title}""".format_map({"title": title})

        # start_point和end_point仅表示数据区域
        # 表头区域需要 在数据区域基础上-1， 表单区域目前定义的是包括 表头和数据区域
        start_col = digit2alphabet(int(data_dict['start_point'][1]))
        start_row = int(data_dict['start_point'][0])

        end_col = digit2alphabet(int(data_dict['end_point'][1]))
        end_row = int(data_dict['end_point'][0])

        try:
            header_start_row = int(data_dict['header_start_point'][0])
            header_end_row = int(data_dict['header_end_point'][0])
        except:
            # 没有表头的情况
            header_start_row = start_row - 1
            header_end_row = start_row - 1

        if 'headers' not in data_dict:
            col_data_str = ""
        else:
            col_data_str, max_score = fmt_header_value(data_dict, relativity_param=input_dict['question'])
            if not max_score_lst:
                max_score_idx = i
            if max_score_lst and max_score > max(max_score_lst):
                max_score_idx = i
            max_score_lst.append(max_score)

        header_data = table_area_str.format_map({
            "idx": str(num + 1),
            "start_point": start_row + 1,
            "end_point": end_row + 1,
            "header_start_point": header_start_row + 1 if header_start_row >= 0 else 1,
            "header_end_point": header_end_row + 1 if header_end_row >= 0 else 1,
            "table_structure": col_data_str
             })

        num += 1
        output.append(header_data)

    # 当有多个表单区域，根据相关性，获取其中一个做处理
    if len(max_score_lst) > 1 and len(output) > 1 and max(max_score_lst) - min(max_score_lst) > SCORE_THRESHOLD:
        output = [output[max_score_idx]]
        num = len(output)

    final_output_str = "\n".join(output)
    case_table_area = f"{start_col}{start_row}:{end_col}{end_row + 1}"
    # 计算下问题和case 的相似度
    similarity_case = calc_similarity_q_case(input_dict.get('question', ""), case_dict)
    # 若匹配到相似case
    if similarity_case and USE_FEWSHOT:
        prompt = PROMPT_DICT[str(case_dict[similarity_case]['prompt_type'])]
        final_output_str = prompt.format(table_area=final_output_str,
                                         case_table_area=case_table_area,
                                              demand=input_dict.get('question', ""),
                                              ALL_SHEET_NAME=json.dumps(all_sheet_name, ensure_ascii=False),
                                              CUR_SHEET_NAME=sheet_name,
                                              selected_start_col=selected_start_col,
                                              selected_start_row=selected_start_row,
                                              selected_end_col=selected_end_col,
                                              selected_end_row=selected_end_row,
                                              num=num,
                                              active_cell=input_dict.get('active_cell', str(selected_start_col) + str(selected_start_row)),
                                             table_structure=case_dict[similarity_case]['table_structure'],
                                             case_question=similarity_case,
                                             case_answer=case_dict[similarity_case]['answer']
                                              )
    else:
        case_lst = ['取消超链接', '高亮出手机']
        query = input_dict.get('question', "")
        for special_case in case_lst:
            if special_case in query and "选中" not in query:
                final_output_str = NO_SELECTION_FULL_PROMPT.format(table_area=final_output_str,
                                                      demand=input_dict.get('question', ""),
                                                      ALL_SHEET_NAME=json.dumps(all_sheet_name, ensure_ascii=False),
                                                      CUR_SHEET_NAME=sheet_name,
                                                      selected_start_col=selected_start_col,
                                                      selected_start_row=selected_start_row,
                                                      selected_end_col=selected_end_col,
                                                      selected_end_row=selected_end_row,
                                                      num=num,
                                                      active_cell=input_dict.get('active_cell',
                                                                                 str(selected_start_col) + str(
                                                                                     selected_start_row))
                                                      )
                return final_output_str

        final_output_str = prompt.format(table_area=final_output_str,
                                              demand=input_dict.get('question', ""),
                                              ALL_SHEET_NAME=json.dumps(all_sheet_name, ensure_ascii=False),
                                              CUR_SHEET_NAME=sheet_name,
                                              selected_start_col=selected_start_col,
                                              selected_start_row=selected_start_row,
                                              selected_end_col=selected_end_col,
                                              selected_end_row=selected_end_row,
                                              num=num,
                                              active_cell=input_dict.get('active_cell', str(selected_start_col) + str(selected_start_row))
                                              )
    return final_output_str

def del_select_area(selection_range_list):
    selected_start_col = 'A'
    selected_start_row = 1
    selected_end_col = 'A'
    selected_end_row = 1
    try:
        # 仅先处理第一个选中区域
        for item in selection_range_list[:1]:
            selected_start_col = digit2alphabet(int(item[1]))
            selected_start_row = int(item[0]) + 1

            selected_end_col = digit2alphabet(int(item[3]))
            selected_end_row = int(item[2]) + 1
    except:
        selected_start_col = 'A'
        selected_start_row = 1
        selected_end_col = 'A'
        selected_end_row = 1
    return selected_start_col + str(selected_start_row) +":" +  selected_end_col + str(selected_end_row)

def column_to_number(column):
    # 列号 A 转数字
    column = column.upper()  # 将输入的列号转换为大写，以支持不区分大小写
    result = 0

    for char in column:
        result = result * 26 + (ord(char) - ord('A') + 1)

    return result

def connect_error_tables(input_dict):
    all_sheet_name = input_dict['all_sheet_name']
    # 选中区域处理
    # 如果没选中区域，默认A1
    selected_start_col = 'A'
    selected_start_row = 1
    selected_end_col = 'A'
    selected_end_row = 1
    try:
        if "selection_range_list" in input_dict and len(input_dict["selection_range_list"]) > 0:
            # 仅先处理第一个选中区域
            for item in input_dict["selection_range_list"][:1]:
                selected_start_col = digit2alphabet(int(item[1]))
                selected_start_row = int(item[0]) + 1

                selected_end_col = digit2alphabet(int(item[3]))
                selected_end_row = int(item[2]) + 1
    except:
        selected_start_col = 'A'
        selected_start_row = 1
        selected_end_col = 'A'
        selected_end_row = 1

    min_start_point_row = 100000000000
    min_start_point_col = 100000000000
    max_end_point_row = -1
    max_end_point_col = -1
    data_dict = {}
    for idx, item in enumerate(input_dict['tables_json_data']):
        # 找到最小的行，最小的列，和最大的行，最大的列
        if item['start_point'][0] < min_start_point_row:
            min_start_point_row = item['start_point'][0]
            data_dict = item
        if item['start_point'][1] < min_start_point_col:
            min_start_point_col = item['start_point'][1]
        if item['end_point'][0] > max_end_point_row:
            max_end_point_row = item['end_point'][0]
        if item['end_point'][0] > max_end_point_col:
            max_end_point_col = item['end_point'][1]

    start_row = int(min_start_point_row)

    end_row = int(max_end_point_row)
    sheet_name = data_dict['sheet_name']

    if 'headers' not in data_dict:
        col_data_str = ""
    else:
        col_data_str, max_score = fmt_header_value(data_dict, relativity_param=input_dict['question'])
    table_area_str = """表单区域{idx}：
表头起始行号为{header_start_point}，终止行号为{header_end_point}，内容起始行号为{start_point}，终止行号为{end_point}，同时每一列的列索引、列名及示例内容为：{table_structure}。"""
    header_data = table_area_str.format_map({
        "idx": 1,
        "start_point": start_row + 1,
        "end_point": end_row + 1,
        "header_start_point": start_row if start_row > 0 else 1,
        "header_end_point": start_row if start_row > 0 else 1,
        "table_structure": col_data_str
    })
    final_output_str = FULL_PROMPT.format(table_area=header_data,
                                          demand=input_dict.get('question', ""),
                                          ALL_SHEET_NAME=json.dumps(all_sheet_name, ensure_ascii=False),
                                          CUR_SHEET_NAME=sheet_name,
                                          selected_start_col=selected_start_col,
                                          selected_start_row=selected_start_row,
                                          selected_end_col=selected_end_col,
                                          selected_end_row=selected_end_row,
                                          num=1,
                                          active_cell=input_dict.get('active_cell', str(selected_start_col) + str(selected_start_row))
                                          )
    return final_output_str

def gen_table_structure_js_newtable_from_json(input_dict):
    text = input_dict['biz_body']['function_parameters']['tableContent']
    all_sheet_name = input_dict['all_sheet_name']
    select_area = del_select_area(input_dict['selection_range_list'])
    active_cell = input_dict['active_cell']

    # 去除多余的反斜线
    text = text.replace('\\', "")

    output_texts = {}

    # 提取表单区域
    form_datas = re.findall(r'表单区域为："(.*?)"', text)
    if not form_datas:
        form_datas = re.findall(r'表单区域为：(.*?)[,\n]', text)
    start_rows = []
    end_rows = []
    start_cols = []
    end_cols = []
    for form in form_datas:
        try:
            # 使用正则表达式匹配行号
            form = form.replace('$', '')
            match = re.match(r'([A-Z]+)(\d+):\s*([A-Z]+)(\d+)', form)
            start_rows.append(int(match.group(2)))
            end_rows.append(int(match.group(4)))
            start_cols.append(match.group(1))
            end_cols.append(match.group(3))
        except:
            if start_rows and end_rows:
                break

    data_lst = re.split("表单区域\d+", text)

    header_data = []
    my_dict = {}
    if len(data_lst) > MAX_TABLE_AREA:
        return text, False

    # 针对测试集表格结构识别不连通的修复
    if len(start_cols) > 1 and len(end_cols) > 1 and len(set(start_cols)) == 1 and len(set(end_cols)) == 1 and set(start_cols) == set(end_cols):
        min_start_row = min(start_rows)
        min_start_row_idx = start_rows.index(min_start_row)
        max_end_row = max(end_rows)
        start_rows = [min_start_row]
        end_rows = [max_end_row]
        data_lst = [data_lst[0]] + [data_lst[min_start_row_idx + 1]]


    for i in range(1, len(data_lst)):
        # 提取表头信息
        header_data_texts = re.findall(r'表头数据为：(.*?)$', data_lst[i], re.DOTALL)
        sorted_lst = sorted(json.loads(header_data_texts[0]).keys(), key=lambda x: column_to_number(re.sub(r'\d+', '', x)))
        cols = re.findall(r'{(.*?)}', header_data_texts[0], re.DOTALL)
        # 修复AF 1207 没有大括号 } 的问题
        if not cols:
            cols = re.findall(r'{(.*?)$', header_data_texts[0], re.DOTALL)

        for j in range(len(cols)):
            col_list = cols[j].split(",")
            for i, item in enumerate(col_list):
                tmp = item.split(":")
                tmp_char = tmp[0].replace("\"", "")

                tmp[0] = re.sub(r'\d+', '', tmp[0])
                # A, 列名, ""
                x = ", ".join(tmp)
                x = '{' + x + ", \"\"" + "}"
                col_list[i] = x
                my_dict[tmp_char] = x

            cols[j] = ",".join(col_list)
            # # 加大括号
            # cols[j] = "{" + cols[j] + "}"
        new_data = []
        for _ in sorted_lst:
            new_data.append(my_dict[_])

        header_data.append(",".join(new_data))

    num_tables = len(header_data)
    output_texts["num_tables"] = str(num_tables)

    try:
        sheet_start_idx = re.search(r'所有工作表信息如下：', text).span()[1]
        sheet_end_idx, cur_sheet_start_idx = re.search(r'\n当前工作表名称为：', text).span()
        table_names = text[sheet_start_idx:sheet_end_idx].split(",")
        cur_sheet_end_idx = re.search(r'，选中区域为：', text).span()[0]
        output_texts["current_table_name"] = text[cur_sheet_start_idx:cur_sheet_end_idx]
    except:
        return text, False
    # 前后加引号
    # output_texts["table_names_text"] = ",".join(table_names)
    output_texts["table_names_text"] = list(map(lambda x: "\"" + x +"\"", all_sheet_name))
    output_texts["table_names_text"] = ",".join(output_texts["table_names_text"])
    output_texts["select_area"] = select_area
    output_texts["active_cell"] = active_cell

    prefix = '''现有一个excel工作簿，所有工作表的名称如下：[{table_names_text}]，当前工作表名称为："{current_table_name}"，选中区域为："{select_area}"，活动单元格为：{active_cell}。
工作表包含{num_tables}个表单区域：\n'''.format_map(output_texts)
    table_texts = []
    for j in range(num_tables):
        table_text = f'表单区域{j + 1}：\n表头起始行号为{start_rows[j]}，终止行号为{start_rows[j]}，内容起始行号为{int(start_rows[j]) + 1}，终止行号为{end_rows[j]}，同时每一列的列索引、列名及示例内容为：{header_data[j]}'
        table_texts.append(table_text)
    return prefix + "\n".join(table_texts), True


async def req_table_structure(request_id, tables, tables_encoding, user_query, input_dict, case_dict):
    try:
        headers = {
            "Host": MATCH_TABLE_HOST,
            "Content-Type": "application/json; charset=utf8",
            "Jm-Client-Type": MATCH_TABLE_ClientType,
            "Jm-Client-Entrance": MATCH_TABLE_JmClientEntrance,
            "Jm-Appid": MATCH_TABLE_JmAppid,
            "Jm-Reqid": request_id,
            "Jm-Internal-Token": MATCH_TABLE_TOKEN
        }
        req_table_data = {
            "tables": tables,
            "tables_encoding": tables_encoding,
            "question": user_query
        }
        # table_data = match_table(req_table_data, headers=headers)
        table_data = await asyncio.get_event_loop().run_in_executor(None, match_table, req_table_data, headers, request_id)
        tables_bytes = binascii.a2b_base64(table_data['data']['tables'])
        tables_bytes = gzip.decompress(tables_bytes).decode('utf-8')
        input_dict['tables_json_data'] = json.loads(tables_bytes)
        # input_dict["tables"] = table_data.get("data", {}).get("tables", [])
    except:
        return None

    try:
        prompt = gen_js_table_structure(input_dict, case_dict)
    except:
        return None
    return prompt

def loadFromFile():
    filepath = os.path.join(os.getcwd(), "case.xlsx")
    if os.path.exists(filepath):
        workbook = openpyxl.load_workbook(filepath)
    else:
        workbook = openpyxl.load_workbook(os.path.join(os.getcwd(), "core", "case.xlsx"))

    ex = defaultdict(dict)
    # 遍历每个Sheet
    for sheet_name in workbook.sheetnames:
        sheet = workbook[sheet_name]
        # 遍历每行数据
        key = ''
        for row in sheet.iter_rows(min_row=2, values_only=True):
            if row[0] is None:
                continue
            ex[row[0]]['table_structure'] = row[1]
            ex[row[0]]['answer'] = row[2]
            ex[row[0]]['prompt_type'] = row[3]
            ex[row[0]]['score'] = float(row[4])

    return ex

# ####
# 测试用

# print(fmt_header_value({
#     "function_type": "FORMATCONDITION",
#     "question": "金额中小于100的单元格标红",
#     "tables": [
#         {"data": {
#                 "数量": [
#                     20,
#                     40,
#                     60,
#                     80,
#                     0,
#                     0
#                 ],
#                 "日期": [
#                     "",
#                     "",
#                     "",
#                     "",
#                     "",
#                     ""
#                 ],
#                 "品名/规格/颜色/其它明细": [
#                     "",
#                     "",
#                     "",
#                     "",
#                     "",
#                     ""
#                 ],
#                 "单价": [
#                     "12",
#                     "13",
#                     "14",
#                     "8",
#                     "9",
#                     "10"
#                 ],
#                 "金额": [
#                    "12",
#                     "13",
#                     "14",
#                     "8",
#                     "9",
#                     "10"
#                 ]
#             },
#             "headers": [
#                 "日期",
#                 "品名/规格/颜色/其它明细",
#                 "数量",
#                 "单价",
#                 "金额"
#             ],
#             "table_id": "8ee907a0-8bbc-5b88-83f3-65363dbff7d1",
#             "sheet_name": "思立印刷校对表",
#             "title": "移印/烫",
#             "file_name": "2016印刷明细表",
#             "start_point": [
#                 1,
#                 1
#             ],
#             "end_point": [
#                 5,
#                 5
#             ]
#         },{"data": {
#                 "数量": [
#                     20,
#                     40,
#                     60,
#                     80,
#                     0,
#                     0
#                 ],
#                 "日期": [
#                     "",
#                     "",
#                     "",
#                     "",
#                     "",
#                     ""
#                 ],
#                 "品名/规格/颜色/其它明细": [
#                     "",
#                     "",
#                     "",
#                     "",
#                     "",
#                     ""
#                 ],
#                 "单价": [
#                     "12",
#                     "13",
#                     "14",
#                     "8",
#                     "9",
#                     "10"
#                 ],
#                 "金额": [
#                    "12",
#                     "13",
#                     "14",
#                     "8",
#                     "9",
#                     "10"
#                 ]
#             },
#             "headers": [
#                 "日期",
#                 "品名/规格/颜色/其它明细",
#                 "数量",
#                 "单价",
#                 "金额"
#             ],
#             "table_id": "8ee907a0-8bbc-5b88-83f3-65363dbff7d1",
#             "sheet_name": "思立印刷校对表",
#             "title": "移印/烫",
#             "file_name": "2016印刷明细表",
#             "start_point": [
#                 1,
#                 1
#             ],
#             "end_point": [
#                 5,
#                 5
#             ]
#         }
#     ],
#     "selection_range_list": [[24,7,25,7]],
#     "active_cell": "A1",
#     "all_sheet_name": ["Sheet1", "Sheet2", "Sheet3"]
# }["tables"][0]))
#
# gen_js_table_structure({
#     "function_type": "FORMATCONDITION",
#     "question": "金额中小于100的单元格标红",
#     "tables": [
#         {"data": {
#                 "数量": [
#                     20,
#                     40,
#                     60,
#                     80,
#                     0,
#                     0
#                 ],
#                 "日期": [
#                     "",
#                     "",
#                     "",
#                     "",
#                     "",
#                     ""
#                 ],
#                 "品名/规格/颜色/其它明细": [
#                     "",
#                     "",
#                     "",
#                     "",
#                     "",
#                     ""
#                 ],
#                 "单价": [
#                     "12",
#                     "13",
#                     "14",
#                     "8",
#                     "9",
#                     "10"
#                 ],
#                 "金额": [
#                    "12",
#                     "13",
#                     "14",
#                     "8",
#                     "9",
#                     "10"
#                 ]
#             },
#             "headers": [
#                 "日期",
#                 "品名/规格/颜色/其它明细",
#                 "数量",
#                 "单价",
#                 "金额"
#             ],
#             "table_id": "8ee907a0-8bbc-5b88-83f3-65363dbff7d1",
#             "sheet_name": "思立印刷校对表",
#             "title": "移印/烫",
#             "file_name": "2016印刷明细表",
#             "start_point": [
#                 1,
#                 1
#             ],
#             "end_point": [
#                 5,
#                 5
#             ]
#         },{"data": {
#                 "数量": [
#                     20,
#                     40,
#                     60,
#                     80,
#                     0,
#                     0
#                 ],
#                 "日期": [
#                     "",
#                     "",
#                     "",
#                     "",
#                     "",
#                     ""
#                 ],
#                 "品名/规格/颜色/其它明细": [
#                     "",
#                     "",
#                     "",
#                     "",
#                     "",
#                     ""
#                 ],
#                 "单价": [
#                     "12",
#                     "13",
#                     "14",
#                     "8",
#                     "9",
#                     "10"
#                 ],
#                 "金额": [
#                    "12",
#                     "13",
#                     "14",
#                     "8",
#                     "9",
#                     "10"
#                 ]
#             },
#             "headers": [
#                 "日期",
#                 "品名/规格/颜色/其它明细",
#                 "数量",
#                 "单价",
#                 "金额"
#             ],
#             "table_id": "8ee907a0-8bbc-5b88-83f3-65363dbff7d1",
#             "sheet_name": "思立印刷校对表",
#             "title": "移印/烫",
#             "file_name": "2016印刷明细表",
#             "start_point": [
#                 1,
#                 1
#             ],
#             "end_point": [
#                 5,
#                 5
#             ]
#         }
#     ],
#     "selection_range_list": [[24,7,25,7]],
#     "active_cell": "A1",
#     "all_sheet_name": ["Sheet1", "Sheet2", "Sheet3"]
# })